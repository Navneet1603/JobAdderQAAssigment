package JobAdderTestCases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class SauceLabsLoginTestCases {
	Properties property;
	FileInputStream fs;

	@Test
	public void InvalidLogin_VerifyError() throws IOException {

		fs = new FileInputStream(System.getProperty("user.dir") + "\\config.properties");
		property = new Properties();
		property.load(fs);

		// Setting system properties of ChromeDriver

		System.setProperty("webdriver.chrome.driver", "/work/chromedriver.exe");

		// Creating an object of ChromeDriver

		WebDriver driver = new ChromeDriver();
		;
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.get(property.getProperty("URL")); // Open Page URL

		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='user-name']")));

		// Enter Invalid Credentials
		driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys(property.getProperty("Invaliduser"));

		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(property.getProperty("Invalidpassword"));
		;

		driver.findElement(By.xpath("//input[@id='login-button']")).click();
		System.out.println("Login Failed");

		// Capture error message
		String actualMsg = driver.findElement(By.xpath("//div[@id=\"login_button_container\"]/div/form/h3")).getText();

		// Store message in variable
		String errorMsg = "Epic sadface: Username and password do not match any user in this service";

		// Verify error message
		if (actualMsg.contains(errorMsg)) {
			System.out.println("Error Verified");
		} else {
			System.out.println("Error Not Verified");
		}
		driver.close();

		driver.quit();

	}

	@Test
	public void ValidLogin() {
		// Setting system properties of ChromeDriver
		System.setProperty("webdriver.chrome.driver", "/work/chromedriver.exe");

		// Creating an object of ChromeDriver
		WebDriver driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Open Page URL
		driver.get(property.getProperty("URL"));

		// Enter Username
		driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys(property.getProperty("username"));
		// Enter Password
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(property.getProperty("password"));

		// Login
		driver.findElement(By.xpath("//input[@id='login-button']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("Login Successful");

		driver.close();
		driver.quit();
	}
}
