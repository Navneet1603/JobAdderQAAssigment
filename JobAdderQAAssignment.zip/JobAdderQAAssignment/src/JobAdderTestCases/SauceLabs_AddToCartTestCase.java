package JobAdderTestCases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.excel.utility.Xls_Reader;

public class SauceLabs_AddToCartTestCase {

	Properties property;
	FileInputStream fs;

	@Test
	public void AddToCart() throws IOException {
		fs = new FileInputStream(System.getProperty("user.dir") + "\\config.properties");
		property = new Properties();
		property.load(fs);

		// Setting system properties of ChromeDriver
		System.setProperty("webdriver.chrome.driver", "/work/chromedriver.exe");
		// Creating an object of ChromeDriver
		WebDriver driver = new ChromeDriver();

		// Open Page URL
		driver.get(property.getProperty("URL"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Enter Username
		driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys(property.getProperty("username"));
		// Enter Password
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(property.getProperty("password"));

		// Login
		driver.findElement(By.xpath("//input[@id='login-button']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("Login Successful");

		// Select the Product
		System.out.println(driver.findElement(By.id("item_0_title_link")).getText() + " is selected");
		driver.findElement(By.id("item_0_title_link")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Add to Cart
		driver.findElement(By.xpath("//button[contains(text(), 'ADD TO CART')]")).click();
		driver.findElement(By.xpath("//button[contains(text(), '<- Back')]")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Checking product is available in cart or not
		driver.findElement(By.xpath("//div[@id='shopping_cart_container\']/a/span")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//div[@id='shopping_cart_container\']/a/span")).getText(),
				"1");
		System.out.println(driver.findElement(By.xpath("//div[@id='shopping_cart_container\']/a/span")).getText()
				+ " 1 product has been added to the cart" + "\nResult Verified");
		driver.close();
		driver.quit();

	}

	@Test
	public void parameterization() throws IOException {

		fs = new FileInputStream(System.getProperty("user.dir") + "\\config.properties");
		property = new Properties();
		property.load(fs);

		// Setting system properties of ChromeDriver
		System.setProperty("webdriver.chrome.driver", "/work/chromedriver.exe");
		// Creating an object of ChromeDriver
		WebDriver driver = new ChromeDriver();

		// Open Page URL
		driver.get(property.getProperty("URL"));
		driver.manage().window().maximize();

		// read data from Excel
		Xls_Reader reader = new Xls_Reader(System.getProperty("user.dir") + "\\src\\TestData\\SauceLabsTestData.xlsx");

		int rowCount = reader.getRowCount("TestData");

		// Enter Username
		driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys(property.getProperty("username"));
		// Enter Password
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(property.getProperty("password"));

		// Login
		driver.findElement(By.xpath("//input[@id='login-button']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("Login Successful");

		// parameterization:
		for (int rowNum = 2; rowNum <= rowCount; rowNum++) {
			System.out.println("======");
			String ProductID = reader.getCellData("TestData", "ProductId", rowNum);
			System.out.println(ProductID);
			String ProductNM = reader.getCellData("TestData", "ProductName", rowNum);
			System.out.println(ProductNM);

			System.out.println("Login Successful");
			// Select the Product
			driver.findElement(By.id(ProductID)).click();
			// Add to Cart
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//button[contains(text(), 'ADD TO CART')]")).click();
			driver.findElement(By.xpath("//button[contains(text(), '<- Back')]")).click();

		}

		// Checking product is available in cart or not
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//div[@id='shopping_cart_container\']/a/span")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//div[@id='shopping_cart_container\']/a/span")).getText(),
				"6");
		System.out.println(driver.findElement(By.xpath("//div[@id='shopping_cart_container\']/a/span")).getText()
				+ " All the product has been added to the cart" + "\nResult Verified");
		driver.close();
		driver.quit();

	}

}
