package com.excel.utility;

import java.util.ArrayList;

public class TestUtil {
	static Xls_Reader reader;

	public static ArrayList<Object[]> getDataFromExcel() {
		ArrayList<Object[]> myData = new ArrayList<Object[]>();
		try {
			reader = new Xls_Reader("C:\\work\\SauceLabsTestData.xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}

		for (int rowNum = 2; rowNum <= reader.getRowCount("RegRowData"); rowNum++) {

			String Product = reader.getCellData("RegRowData", "Product", rowNum);
			Object ob[] = { Product };
			myData.add(ob);

		}
		return myData;
	}

}
